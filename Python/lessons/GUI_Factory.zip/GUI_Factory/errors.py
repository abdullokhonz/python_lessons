index_error: str = 'Error: Unknown parameter, such parameter does not exist!'
value_error: str = 'Error: You can only enter numbers!'
